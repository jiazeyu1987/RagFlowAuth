RagflowAuth inspection evidence export
Exported at: 2026-04-13T18:50:07+08:00
Exported by: 6567f115-49f7-49a3-86cf-2282ae823975
Filters: {"source": "smart_chat"}
Human readable copy: CSV
Portable structured copy: JSON
Integrity summary: manifest.json and checksums.json
Counts: {"approval_actions": 0, "audit_events": 1, "backup_jobs": 7, "electronic_signatures": 0, "notification_jobs": 0, "restore_drills": 0}
